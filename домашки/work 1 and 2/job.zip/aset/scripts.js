function countFF(){
    alert("Анкета отправлена")
}
